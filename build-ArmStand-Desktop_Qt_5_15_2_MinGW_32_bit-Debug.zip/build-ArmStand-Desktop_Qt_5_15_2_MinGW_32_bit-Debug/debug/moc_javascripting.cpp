/****************************************************************************
** Meta object code from reading C++ file 'javascripting.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/javascripting.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'javascripting.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_UniTrace_t {
    QByteArrayData data[35];
    char stringdata0[299];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UniTrace_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UniTrace_t qt_meta_stringdata_UniTrace = {
    {
QT_MOC_LITERAL(0, 0, 8), // "UniTrace"
QT_MOC_LITERAL(1, 9, 11), // "printSignal"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 4), // "text"
QT_MOC_LITERAL(4, 27, 14), // "sendRcrsSignal"
QT_MOC_LITERAL(5, 42, 12), // "logicChannel"
QT_MOC_LITERAL(6, 55, 7), // "regName"
QT_MOC_LITERAL(7, 63, 10), // "regAddress"
QT_MOC_LITERAL(8, 74, 6), // "nodeId"
QT_MOC_LITERAL(9, 81, 6), // "uartId"
QT_MOC_LITERAL(10, 88, 3), // "len"
QT_MOC_LITERAL(11, 92, 6), // "offset"
QT_MOC_LITERAL(12, 99, 14), // "sendScrsSignal"
QT_MOC_LITERAL(13, 114, 9), // "valueType"
QT_MOC_LITERAL(14, 124, 7), // "nameReg"
QT_MOC_LITERAL(15, 132, 9), // "sentValue"
QT_MOC_LITERAL(16, 142, 8), // "mulValue"
QT_MOC_LITERAL(17, 151, 11), // "readHandler"
QT_MOC_LITERAL(18, 163, 4), // "data"
QT_MOC_LITERAL(19, 168, 6), // "status"
QT_MOC_LITERAL(20, 175, 5), // "print"
QT_MOC_LITERAL(21, 181, 4), // "wait"
QT_MOC_LITERAL(22, 186, 7), // "milisec"
QT_MOC_LITERAL(23, 194, 8), // "waitLast"
QT_MOC_LITERAL(24, 203, 5), // "write"
QT_MOC_LITERAL(25, 209, 4), // "read"
QT_MOC_LITERAL(26, 214, 7), // "readMem"
QT_MOC_LITERAL(27, 222, 8), // "retError"
QT_MOC_LITERAL(28, 231, 10), // "retWarning"
QT_MOC_LITERAL(29, 242, 9), // "setSource"
QT_MOC_LITERAL(30, 252, 6), // "source"
QT_MOC_LITERAL(31, 259, 8), // "saveData"
QT_MOC_LITERAL(32, 268, 4), // "name"
QT_MOC_LITERAL(33, 273, 13), // "readDataToMem"
QT_MOC_LITERAL(34, 287, 11) // "timeoutData"

    },
    "UniTrace\0printSignal\0\0text\0sendRcrsSignal\0"
    "logicChannel\0regName\0regAddress\0nodeId\0"
    "uartId\0len\0offset\0sendScrsSignal\0"
    "valueType\0nameReg\0sentValue\0mulValue\0"
    "readHandler\0data\0status\0print\0wait\0"
    "milisec\0waitLast\0write\0read\0readMem\0"
    "retError\0retWarning\0setSource\0source\0"
    "saveData\0name\0readDataToMem\0timeoutData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UniTrace[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   94,    2, 0x06 /* Public */,
       4,    7,   97,    2, 0x06 /* Public */,
      12,   10,  112,    2, 0x06 /* Public */,
      17,    3,  133,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      20,    1,  140,    2, 0x0a /* Public */,
      21,    1,  143,    2, 0x0a /* Public */,
      23,    1,  146,    2, 0x0a /* Public */,
      24,    2,  149,    2, 0x0a /* Public */,
      25,    1,  154,    2, 0x0a /* Public */,
      26,    1,  157,    2, 0x0a /* Public */,
      27,    1,  160,    2, 0x0a /* Public */,
      28,    1,  163,    2, 0x0a /* Public */,
      29,    1,  166,    2, 0x0a /* Public */,
      31,    2,  169,    2, 0x0a /* Public */,
      33,    3,  174,    2, 0x0a /* Public */,
      34,    0,  181,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,    6,    7,    8,    9,   10,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,   13,   14,   15,    7,    8,    9,   10,   11,   16,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    6,   18,   19,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    6,   18,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::QString, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,   30,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   32,   18,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    6,   18,   19,
    QMetaType::Void,

       0        // eod
};

void UniTrace::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UniTrace *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->printSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->sendRcrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 2: _t->sendScrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 3: _t->readHandler((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 4: _t->print((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->wait((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->waitLast((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->write((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 8: _t->read((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: { QString _r = _t->readMem((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 10: _t->retError((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->retWarning((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->setSource((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->saveData((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 14: _t->readDataToMem((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 15: _t->timeoutData(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UniTrace::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UniTrace::printSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (UniTrace::*)(qint32 , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UniTrace::sendRcrsSignal)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (UniTrace::*)(qint32 , QString , QString , QString , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UniTrace::sendScrsSignal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (UniTrace::*)(QString , QString , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UniTrace::readHandler)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject UniTrace::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_UniTrace.data,
    qt_meta_data_UniTrace,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *UniTrace::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UniTrace::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_UniTrace.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QScriptable"))
        return static_cast< QScriptable*>(this);
    return QObject::qt_metacast(_clname);
}

int UniTrace::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void UniTrace::printSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void UniTrace::sendRcrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void UniTrace::sendScrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7, QString _t8, QString _t9, QString _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void UniTrace::readHandler(QString _t1, QString _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
struct qt_meta_stringdata_JavaScripting_t {
    QByteArrayData data[36];
    char stringdata0[376];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_JavaScripting_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_JavaScripting_t qt_meta_stringdata_JavaScripting = {
    {
QT_MOC_LITERAL(0, 0, 13), // "JavaScripting"
QT_MOC_LITERAL(1, 14, 11), // "printReport"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 4), // "text"
QT_MOC_LITERAL(4, 32, 14), // "sendRcrsSignal"
QT_MOC_LITERAL(5, 47, 12), // "logicChannel"
QT_MOC_LITERAL(6, 60, 7), // "regName"
QT_MOC_LITERAL(7, 68, 10), // "regAddress"
QT_MOC_LITERAL(8, 79, 6), // "nodeId"
QT_MOC_LITERAL(9, 86, 6), // "uartId"
QT_MOC_LITERAL(10, 93, 3), // "len"
QT_MOC_LITERAL(11, 97, 6), // "offset"
QT_MOC_LITERAL(12, 104, 14), // "sendScrsSignal"
QT_MOC_LITERAL(13, 119, 9), // "valueType"
QT_MOC_LITERAL(14, 129, 7), // "nameReg"
QT_MOC_LITERAL(15, 137, 9), // "sentValue"
QT_MOC_LITERAL(16, 147, 8), // "mulValue"
QT_MOC_LITERAL(17, 156, 11), // "readHandler"
QT_MOC_LITERAL(18, 168, 4), // "data"
QT_MOC_LITERAL(19, 173, 6), // "status"
QT_MOC_LITERAL(20, 180, 16), // "endScriptSuccess"
QT_MOC_LITERAL(21, 197, 4), // "name"
QT_MOC_LITERAL(22, 202, 4), // "page"
QT_MOC_LITERAL(23, 207, 14), // "runJScriptSlot"
QT_MOC_LITERAL(24, 222, 6), // "script"
QT_MOC_LITERAL(25, 229, 5), // "print"
QT_MOC_LITERAL(26, 235, 12), // "sendRcrsSlot"
QT_MOC_LITERAL(27, 248, 12), // "sendScrsSlot"
QT_MOC_LITERAL(28, 261, 12), // "readAdamData"
QT_MOC_LITERAL(29, 274, 22), // "DATA_UART_ADAM_PACKET*"
QT_MOC_LITERAL(30, 297, 10), // "adamPacekt"
QT_MOC_LITERAL(31, 308, 14), // "readModbusData"
QT_MOC_LITERAL(32, 323, 17), // "MODBUS_RX_STRUCT*"
QT_MOC_LITERAL(33, 341, 12), // "modBusPacket"
QT_MOC_LITERAL(34, 354, 12), // "readSCPIData"
QT_MOC_LITERAL(35, 367, 8) // "SCPIdata"

    },
    "JavaScripting\0printReport\0\0text\0"
    "sendRcrsSignal\0logicChannel\0regName\0"
    "regAddress\0nodeId\0uartId\0len\0offset\0"
    "sendScrsSignal\0valueType\0nameReg\0"
    "sentValue\0mulValue\0readHandler\0data\0"
    "status\0endScriptSuccess\0name\0page\0"
    "runJScriptSlot\0script\0print\0sendRcrsSlot\0"
    "sendScrsSlot\0readAdamData\0"
    "DATA_UART_ADAM_PACKET*\0adamPacekt\0"
    "readModbusData\0MODBUS_RX_STRUCT*\0"
    "modBusPacket\0readSCPIData\0SCPIdata"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_JavaScripting[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   74,    2, 0x06 /* Public */,
       4,    7,   77,    2, 0x06 /* Public */,
      12,   10,   92,    2, 0x06 /* Public */,
      17,    3,  113,    2, 0x06 /* Public */,
      20,    3,  120,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      23,    3,  127,    2, 0x0a /* Public */,
      25,    1,  134,    2, 0x0a /* Public */,
      26,    7,  137,    2, 0x0a /* Public */,
      27,   10,  152,    2, 0x0a /* Public */,
      28,    1,  173,    2, 0x0a /* Public */,
      31,    2,  176,    2, 0x0a /* Public */,
      34,    3,  181,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,    6,    7,    8,    9,   10,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,   13,   14,   15,    7,    8,    9,   10,   11,   16,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    6,   18,   19,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Bool,   21,   22,   19,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   21,   22,   24,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,    6,    7,    8,    9,   10,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,   13,   14,   15,    7,    8,    9,   10,   11,   16,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void, 0x80000000 | 32, QMetaType::QString,   33,    5,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   35,    5,    6,

       0        // eod
};

void JavaScripting::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<JavaScripting *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->printReport((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->sendRcrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 2: _t->sendScrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 3: _t->readHandler((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 4: _t->endScriptSuccess((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 5: _t->runJScriptSlot((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 6: _t->print((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->sendRcrsSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 8: _t->sendScrsSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 9: _t->readAdamData((*reinterpret_cast< DATA_UART_ADAM_PACKET*(*)>(_a[1]))); break;
        case 10: _t->readModbusData((*reinterpret_cast< MODBUS_RX_STRUCT*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 11: _t->readSCPIData((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (JavaScripting::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&JavaScripting::printReport)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (JavaScripting::*)(qint32 , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&JavaScripting::sendRcrsSignal)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (JavaScripting::*)(qint32 , QString , QString , QString , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&JavaScripting::sendScrsSignal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (JavaScripting::*)(QString , QString , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&JavaScripting::readHandler)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (JavaScripting::*)(qint32 , qint32 , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&JavaScripting::endScriptSuccess)) {
                *result = 4;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject JavaScripting::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_JavaScripting.data,
    qt_meta_data_JavaScripting,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *JavaScripting::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *JavaScripting::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_JavaScripting.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int JavaScripting::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void JavaScripting::printReport(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void JavaScripting::sendRcrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void JavaScripting::sendScrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7, QString _t8, QString _t9, QString _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void JavaScripting::readHandler(QString _t1, QString _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void JavaScripting::endScriptSuccess(qint32 _t1, qint32 _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
