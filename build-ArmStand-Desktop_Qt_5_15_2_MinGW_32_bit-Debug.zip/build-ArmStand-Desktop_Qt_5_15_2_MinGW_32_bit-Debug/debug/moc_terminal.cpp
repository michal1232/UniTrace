/****************************************************************************
** Meta object code from reading C++ file 'terminal.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/terminal.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'terminal.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_terminalT_t {
    QByteArrayData data[25];
    char stringdata0[202];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_terminalT_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_terminalT_t qt_meta_stringdata_terminalT = {
    {
QT_MOC_LITERAL(0, 0, 9), // "terminalT"
QT_MOC_LITERAL(1, 10, 12), // "getRadialCol"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 6), // "colVal"
QT_MOC_LITERAL(4, 31, 8), // "getTogle"
QT_MOC_LITERAL(5, 40, 4), // "time"
QT_MOC_LITERAL(6, 45, 4), // "lctx"
QT_MOC_LITERAL(7, 50, 2), // "nl"
QT_MOC_LITERAL(8, 53, 4), // "echo"
QT_MOC_LITERAL(9, 58, 2), // "cr"
QT_MOC_LITERAL(10, 61, 2), // "lf"
QT_MOC_LITERAL(11, 64, 4), // "lcrx"
QT_MOC_LITERAL(12, 69, 13), // "getDataInTerm"
QT_MOC_LITERAL(13, 83, 6), // "dataIn"
QT_MOC_LITERAL(14, 90, 12), // "setRadialCol"
QT_MOC_LITERAL(15, 103, 7), // "setTime"
QT_MOC_LITERAL(16, 111, 7), // "setLctx"
QT_MOC_LITERAL(17, 119, 7), // "setEcho"
QT_MOC_LITERAL(18, 127, 5), // "setNl"
QT_MOC_LITERAL(19, 133, 5), // "setCr"
QT_MOC_LITERAL(20, 139, 5), // "setLf"
QT_MOC_LITERAL(21, 145, 7), // "setLcrx"
QT_MOC_LITERAL(22, 153, 13), // "setDataInTerm"
QT_MOC_LITERAL(23, 167, 15), // "clearDataInTerm"
QT_MOC_LITERAL(24, 183, 18) // "onTerminalComplete"

    },
    "terminalT\0getRadialCol\0\0colVal\0getTogle\0"
    "time\0lctx\0nl\0echo\0cr\0lf\0lcrx\0getDataInTerm\0"
    "dataIn\0setRadialCol\0setTime\0setLctx\0"
    "setEcho\0setNl\0setCr\0setLf\0setLcrx\0"
    "setDataInTerm\0clearDataInTerm\0"
    "onTerminalComplete"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_terminalT[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   84,    2, 0x06 /* Public */,
       4,    7,   87,    2, 0x06 /* Public */,
      12,    1,  102,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    1,  105,    2, 0x0a /* Public */,
      15,    1,  108,    2, 0x0a /* Public */,
      16,    1,  111,    2, 0x0a /* Public */,
      17,    1,  114,    2, 0x0a /* Public */,
      18,    1,  117,    2, 0x0a /* Public */,
      19,    1,  120,    2, 0x0a /* Public */,
      20,    1,  123,    2, 0x0a /* Public */,
      21,    1,  126,    2, 0x0a /* Public */,
      22,    1,  129,    2, 0x0a /* Public */,
      23,    0,  132,    2, 0x0a /* Public */,
      24,    0,  133,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int,    5,    6,    7,    8,    9,   10,   11,
    QMetaType::Void, QMetaType::QString,   13,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void terminalT::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<terminalT *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->getRadialCol((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 1: _t->getTogle((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< qint32(*)>(_a[7]))); break;
        case 2: _t->getDataInTerm((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->setRadialCol((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 4: _t->setTime((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->setLctx((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->setEcho((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->setNl((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->setCr((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->setLf((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->setLcrx((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 11: _t->setDataInTerm((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->clearDataInTerm(); break;
        case 13: _t->onTerminalComplete(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (terminalT::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&terminalT::getRadialCol)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (terminalT::*)(bool , bool , bool , bool , bool , bool , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&terminalT::getTogle)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (terminalT::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&terminalT::getDataInTerm)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject terminalT::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_terminalT.data,
    qt_meta_data_terminalT,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *terminalT::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *terminalT::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_terminalT.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int terminalT::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void terminalT::getRadialCol(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void terminalT::getTogle(bool _t1, bool _t2, bool _t3, bool _t4, bool _t5, bool _t6, qint32 _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void terminalT::getDataInTerm(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
