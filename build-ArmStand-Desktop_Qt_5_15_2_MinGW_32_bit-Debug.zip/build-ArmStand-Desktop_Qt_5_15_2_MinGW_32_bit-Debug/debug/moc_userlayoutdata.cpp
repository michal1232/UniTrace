/****************************************************************************
** Meta object code from reading C++ file 'userlayoutdata.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/userlayoutdata.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'userlayoutdata.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_UserLayoutData_t {
    QByteArrayData data[105];
    char stringdata0[1173];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UserLayoutData_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UserLayoutData_t qt_meta_stringdata_UserLayoutData = {
    {
QT_MOC_LITERAL(0, 0, 14), // "UserLayoutData"
QT_MOC_LITERAL(1, 15, 15), // "addToLayoutList"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 6), // "typeOf"
QT_MOC_LITERAL(4, 39, 1), // "x"
QT_MOC_LITERAL(5, 41, 1), // "y"
QT_MOC_LITERAL(6, 43, 5), // "width"
QT_MOC_LITERAL(7, 49, 6), // "height"
QT_MOC_LITERAL(8, 56, 7), // "regName"
QT_MOC_LITERAL(9, 64, 8), // "function"
QT_MOC_LITERAL(10, 73, 5), // "label"
QT_MOC_LITERAL(11, 79, 5), // "value"
QT_MOC_LITERAL(12, 85, 3), // "cnt"
QT_MOC_LITERAL(13, 89, 15), // "layoutComplited"
QT_MOC_LITERAL(14, 105, 18), // "deleteToLayoutList"
QT_MOC_LITERAL(15, 124, 5), // "point"
QT_MOC_LITERAL(16, 130, 10), // "refreshObj"
QT_MOC_LITERAL(17, 141, 16), // "changeXYproperty"
QT_MOC_LITERAL(18, 158, 20), // "changeSeqValueSignal"
QT_MOC_LITERAL(19, 179, 3), // "row"
QT_MOC_LITERAL(20, 183, 3), // "col"
QT_MOC_LITERAL(21, 187, 4), // "data"
QT_MOC_LITERAL(22, 192, 9), // "getSelReg"
QT_MOC_LITERAL(23, 202, 4), // "page"
QT_MOC_LITERAL(24, 207, 8), // "sendRCRS"
QT_MOC_LITERAL(25, 216, 12), // "logicChannel"
QT_MOC_LITERAL(26, 229, 10), // "regAddress"
QT_MOC_LITERAL(27, 240, 6), // "nodeId"
QT_MOC_LITERAL(28, 247, 6), // "uartId"
QT_MOC_LITERAL(29, 254, 3), // "len"
QT_MOC_LITERAL(30, 258, 6), // "offset"
QT_MOC_LITERAL(31, 265, 8), // "sendSCRS"
QT_MOC_LITERAL(32, 274, 9), // "valueType"
QT_MOC_LITERAL(33, 284, 7), // "nameReg"
QT_MOC_LITERAL(34, 292, 9), // "sentValue"
QT_MOC_LITERAL(35, 302, 8), // "mulValue"
QT_MOC_LITERAL(36, 311, 8), // "printReg"
QT_MOC_LITERAL(37, 320, 8), // "regValue"
QT_MOC_LITERAL(38, 329, 12), // "printRegName"
QT_MOC_LITERAL(39, 342, 15), // "printToTerminal"
QT_MOC_LITERAL(40, 358, 7), // "txtData"
QT_MOC_LITERAL(41, 366, 3), // "src"
QT_MOC_LITERAL(42, 370, 14), // "getFunctSignal"
QT_MOC_LITERAL(43, 385, 5), // "funct"
QT_MOC_LITERAL(44, 391, 17), // "getFunctRegSignal"
QT_MOC_LITERAL(45, 409, 3), // "reg"
QT_MOC_LITERAL(46, 413, 3), // "num"
QT_MOC_LITERAL(47, 417, 17), // "getDataTypeSignal"
QT_MOC_LITERAL(48, 435, 8), // "dataType"
QT_MOC_LITERAL(49, 444, 19), // "getNoModifLenSignal"
QT_MOC_LITERAL(50, 464, 12), // "getLenSignal"
QT_MOC_LITERAL(51, 477, 14), // "getRangeSignal"
QT_MOC_LITERAL(52, 492, 3), // "min"
QT_MOC_LITERAL(53, 496, 3), // "max"
QT_MOC_LITERAL(54, 500, 17), // "getBckImageSignal"
QT_MOC_LITERAL(55, 518, 4), // "path"
QT_MOC_LITERAL(56, 523, 13), // "addLayoutPage"
QT_MOC_LITERAL(57, 537, 4), // "name"
QT_MOC_LITERAL(58, 542, 17), // "addFromLayoutList"
QT_MOC_LITERAL(59, 560, 20), // "deleteFromLayoutList"
QT_MOC_LITERAL(60, 581, 22), // "changeXYCoordinateList"
QT_MOC_LITERAL(61, 604, 11), // "changeWidth"
QT_MOC_LITERAL(62, 616, 12), // "changeHeight"
QT_MOC_LITERAL(63, 629, 11), // "changeLabel"
QT_MOC_LITERAL(64, 641, 11), // "changeValue"
QT_MOC_LITERAL(65, 653, 14), // "changeFunction"
QT_MOC_LITERAL(66, 668, 13), // "changeRegName"
QT_MOC_LITERAL(67, 682, 14), // "changeBckImage"
QT_MOC_LITERAL(68, 697, 12), // "changeSeqReg"
QT_MOC_LITERAL(69, 710, 9), // "addSeqRow"
QT_MOC_LITERAL(70, 720, 9), // "delSeqRow"
QT_MOC_LITERAL(71, 730, 9), // "delSeqAll"
QT_MOC_LITERAL(72, 740, 14), // "changeSeqValue"
QT_MOC_LITERAL(73, 755, 15), // "restoreSeqValue"
QT_MOC_LITERAL(74, 771, 13), // "saveSeqToFile"
QT_MOC_LITERAL(75, 785, 10), // "fileSource"
QT_MOC_LITERAL(76, 796, 13), // "loadSeqToFile"
QT_MOC_LITERAL(77, 810, 12), // "loadImageBck"
QT_MOC_LITERAL(78, 823, 8), // "loadPage"
QT_MOC_LITERAL(79, 832, 9), // "retSelReg"
QT_MOC_LITERAL(80, 842, 13), // "DataViewItem*"
QT_MOC_LITERAL(81, 856, 4), // "item"
QT_MOC_LITERAL(82, 861, 7), // "readReg"
QT_MOC_LITERAL(83, 869, 8), // "writeReg"
QT_MOC_LITERAL(84, 878, 10), // "setAdamReg"
QT_MOC_LITERAL(85, 889, 22), // "DATA_UART_ADAM_PACKET*"
QT_MOC_LITERAL(86, 912, 10), // "adamPacekt"
QT_MOC_LITERAL(87, 923, 12), // "setModBusReg"
QT_MOC_LITERAL(88, 936, 17), // "MODBUS_RX_STRUCT*"
QT_MOC_LITERAL(89, 954, 12), // "modBusPacket"
QT_MOC_LITERAL(90, 967, 10), // "setSCPIReg"
QT_MOC_LITERAL(91, 978, 8), // "SCPIdata"
QT_MOC_LITERAL(92, 987, 17), // "setDataToTerminal"
QT_MOC_LITERAL(93, 1005, 6), // "inData"
QT_MOC_LITERAL(94, 1012, 12), // "getFunctSlot"
QT_MOC_LITERAL(95, 1025, 15), // "getFunctRegSlot"
QT_MOC_LITERAL(96, 1041, 11), // "getDataType"
QT_MOC_LITERAL(97, 1053, 17), // "getNoModifLenSlot"
QT_MOC_LITERAL(98, 1071, 10), // "getLenSlot"
QT_MOC_LITERAL(99, 1082, 12), // "getRangeSlot"
QT_MOC_LITERAL(100, 1095, 15), // "getBckImageSlot"
QT_MOC_LITERAL(101, 1111, 20), // "saveLayoutItemToFile"
QT_MOC_LITERAL(102, 1132, 20), // "loadLayoutItemToFile"
QT_MOC_LITERAL(103, 1153, 8), // "closeAll"
QT_MOC_LITERAL(104, 1162, 10) // "clearPage0"

    },
    "UserLayoutData\0addToLayoutList\0\0typeOf\0"
    "x\0y\0width\0height\0regName\0function\0"
    "label\0value\0cnt\0layoutComplited\0"
    "deleteToLayoutList\0point\0refreshObj\0"
    "changeXYproperty\0changeSeqValueSignal\0"
    "row\0col\0data\0getSelReg\0page\0sendRCRS\0"
    "logicChannel\0regAddress\0nodeId\0uartId\0"
    "len\0offset\0sendSCRS\0valueType\0nameReg\0"
    "sentValue\0mulValue\0printReg\0regValue\0"
    "printRegName\0printToTerminal\0txtData\0"
    "src\0getFunctSignal\0funct\0getFunctRegSignal\0"
    "reg\0num\0getDataTypeSignal\0dataType\0"
    "getNoModifLenSignal\0getLenSignal\0"
    "getRangeSignal\0min\0max\0getBckImageSignal\0"
    "path\0addLayoutPage\0name\0addFromLayoutList\0"
    "deleteFromLayoutList\0changeXYCoordinateList\0"
    "changeWidth\0changeHeight\0changeLabel\0"
    "changeValue\0changeFunction\0changeRegName\0"
    "changeBckImage\0changeSeqReg\0addSeqRow\0"
    "delSeqRow\0delSeqAll\0changeSeqValue\0"
    "restoreSeqValue\0saveSeqToFile\0fileSource\0"
    "loadSeqToFile\0loadImageBck\0loadPage\0"
    "retSelReg\0DataViewItem*\0item\0readReg\0"
    "writeReg\0setAdamReg\0DATA_UART_ADAM_PACKET*\0"
    "adamPacekt\0setModBusReg\0MODBUS_RX_STRUCT*\0"
    "modBusPacket\0setSCPIReg\0SCPIdata\0"
    "setDataToTerminal\0inData\0getFunctSlot\0"
    "getFunctRegSlot\0getDataType\0"
    "getNoModifLenSlot\0getLenSlot\0getRangeSlot\0"
    "getBckImageSlot\0saveLayoutItemToFile\0"
    "loadLayoutItemToFile\0closeAll\0clearPage0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UserLayoutData[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      58,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      20,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,   10,  304,    2, 0x06 /* Public */,
      13,    0,  325,    2, 0x06 /* Public */,
      14,    1,  326,    2, 0x06 /* Public */,
      16,    3,  329,    2, 0x06 /* Public */,
      17,    4,  336,    2, 0x06 /* Public */,
      18,    5,  345,    2, 0x06 /* Public */,
      22,    3,  356,    2, 0x06 /* Public */,
      24,    7,  363,    2, 0x06 /* Public */,
      31,   10,  378,    2, 0x06 /* Public */,
      36,    3,  399,    2, 0x06 /* Public */,
      38,    2,  406,    2, 0x06 /* Public */,
      39,    2,  411,    2, 0x06 /* Public */,
      42,    4,  416,    2, 0x06 /* Public */,
      44,    5,  425,    2, 0x06 /* Public */,
      47,    4,  436,    2, 0x06 /* Public */,
      49,    4,  445,    2, 0x06 /* Public */,
      50,    4,  454,    2, 0x06 /* Public */,
      51,    5,  463,    2, 0x06 /* Public */,
      54,    2,  474,    2, 0x06 /* Public */,
      56,    2,  479,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      58,    9,  484,    2, 0x0a /* Public */,
      59,    1,  503,    2, 0x0a /* Public */,
      60,    4,  506,    2, 0x0a /* Public */,
      61,    3,  515,    2, 0x0a /* Public */,
      62,    3,  522,    2, 0x0a /* Public */,
      63,    3,  529,    2, 0x0a /* Public */,
      64,    3,  536,    2, 0x0a /* Public */,
      65,    3,  543,    2, 0x0a /* Public */,
      66,    3,  550,    2, 0x0a /* Public */,
      67,    2,  557,    2, 0x0a /* Public */,
      68,    3,  562,    2, 0x0a /* Public */,
      69,    3,  569,    2, 0x0a /* Public */,
      70,    3,  576,    2, 0x0a /* Public */,
      71,    3,  583,    2, 0x0a /* Public */,
      72,    6,  590,    2, 0x0a /* Public */,
      73,    3,  603,    2, 0x0a /* Public */,
      74,    4,  610,    2, 0x0a /* Public */,
      76,    4,  619,    2, 0x0a /* Public */,
      77,    2,  628,    2, 0x0a /* Public */,
      78,    1,  633,    2, 0x0a /* Public */,
      79,    3,  636,    2, 0x0a /* Public */,
      82,    2,  643,    2, 0x0a /* Public */,
      83,    3,  648,    2, 0x0a /* Public */,
      84,    1,  655,    2, 0x0a /* Public */,
      87,    2,  658,    2, 0x0a /* Public */,
      90,    3,  663,    2, 0x0a /* Public */,
      92,    2,  670,    2, 0x0a /* Public */,
      94,    3,  675,    2, 0x0a /* Public */,
      95,    3,  682,    2, 0x0a /* Public */,
      96,    3,  689,    2, 0x0a /* Public */,
      97,    3,  696,    2, 0x0a /* Public */,
      98,    3,  703,    2, 0x0a /* Public */,
      99,    3,  710,    2, 0x0a /* Public */,
     100,    1,  717,    2, 0x0a /* Public */,
     101,    2,  720,    2, 0x0a /* Public */,
     102,    2,  725,    2, 0x0a /* Public */,
     103,    0,  730,    2, 0x0a /* Public */,
     104,    0,  731,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Int,    3,    4,    5,    6,    7,    8,    9,   10,   11,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   15,   10,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    4,    5,    7,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::QString,   15,    8,   19,   20,   21,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   25,    8,   26,   27,   28,   29,   30,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   25,   32,   33,   34,   26,   27,   28,   29,   30,   35,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   15,   23,   37,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   23,   37,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   40,   41,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   23,   15,   43,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int,   45,   23,   43,   46,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   23,   15,    8,   48,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int,   45,   23,   15,   29,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int,   45,   23,   29,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   45,   23,   52,   53,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   23,   55,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   57,   23,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    3,    4,    5,    6,    7,    8,   10,    9,   11,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int,   15,    3,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   15,    3,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   15,    3,    7,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString,   15,    3,   10,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString,   15,    3,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString,   15,    3,    9,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString,   15,    3,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   23,   55,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,   19,   20,   21,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   23,   15,    8,   75,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   23,   15,    8,   75,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   23,   55,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 80,   23,   15,   81,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   23,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,   21,
    QMetaType::Void, 0x80000000 | 85,   86,
    QMetaType::Void, 0x80000000 | 88, QMetaType::QString,   89,   25,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   91,   25,    8,
    QMetaType::Void, QMetaType::QByteArray, QMetaType::Int,   93,   41,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   15,   23,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   23,    8,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   15,   23,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   23,   15,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   23,    8,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   23,    8,   15,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   75,   23,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   75,   23,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void UserLayoutData::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UserLayoutData *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->addToLayoutList((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< qint32(*)>(_a[10]))); break;
        case 1: _t->layoutComplited(); break;
        case 2: _t->deleteToLayoutList((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 3: _t->refreshObj((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 4: _t->changeXYproperty((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4]))); break;
        case 5: _t->changeSeqValueSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5]))); break;
        case 6: _t->getSelReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 7: _t->sendRCRS((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 8: _t->sendSCRS((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 9: _t->printReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 10: _t->printRegName((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 11: _t->printToTerminal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 12: _t->getFunctSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 13: _t->getFunctRegSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5]))); break;
        case 14: _t->getDataTypeSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 15: _t->getNoModifLenSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4]))); break;
        case 16: _t->getLenSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4]))); break;
        case 17: _t->getRangeSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5]))); break;
        case 18: _t->getBckImageSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 19: _t->addLayoutPage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 20: _t->addFromLayoutList((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9]))); break;
        case 21: _t->deleteFromLayoutList((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 22: _t->changeXYCoordinateList((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4]))); break;
        case 23: _t->changeWidth((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 24: _t->changeHeight((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 25: _t->changeLabel((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 26: _t->changeValue((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 27: _t->changeFunction((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 28: _t->changeRegName((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 29: _t->changeBckImage((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 30: _t->changeSeqReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 31: _t->addSeqRow((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 32: _t->delSeqRow((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 33: _t->delSeqAll((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 34: _t->changeSeqValue((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6]))); break;
        case 35: _t->restoreSeqValue((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 36: _t->saveSeqToFile((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 37: _t->loadSeqToFile((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 38: _t->loadImageBck((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 39: _t->loadPage((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 40: _t->retSelReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< DataViewItem*(*)>(_a[3]))); break;
        case 41: _t->readReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 42: _t->writeReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 43: _t->setAdamReg((*reinterpret_cast< DATA_UART_ADAM_PACKET*(*)>(_a[1]))); break;
        case 44: _t->setModBusReg((*reinterpret_cast< MODBUS_RX_STRUCT*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 45: _t->setSCPIReg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 46: _t->setDataToTerminal((*reinterpret_cast< QByteArray(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 47: _t->getFunctSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 48: _t->getFunctRegSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 49: _t->getDataType((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 50: _t->getNoModifLenSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 51: _t->getLenSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 52: _t->getRangeSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 53: _t->getBckImageSlot((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 54: _t->saveLayoutItemToFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 55: _t->loadLayoutItemToFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 56: _t->closeAll(); break;
        case 57: _t->clearPage0(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UserLayoutData::*)(QString , qint32 , qint32 , qint32 , qint32 , QString , QString , QString , QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::addToLayoutList)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::layoutComplited)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::deleteToLayoutList)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::refreshObj)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::changeXYproperty)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString , qint32 , qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::changeSeqValueSignal)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getSelReg)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::sendRCRS)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString , QString , QString , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::sendSCRS)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::printReg)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::printRegName)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::printToTerminal)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , qint32 , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getFunctSignal)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 , QString , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getFunctRegSignal)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , qint32 , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getDataTypeSignal)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getNoModifLenSignal)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getLenSignal)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getRangeSignal)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::getBckImageSignal)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (UserLayoutData::*)(QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UserLayoutData::addLayoutPage)) {
                *result = 19;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject UserLayoutData::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_UserLayoutData.data,
    qt_meta_data_UserLayoutData,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *UserLayoutData::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UserLayoutData::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_UserLayoutData.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int UserLayoutData::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 58)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 58;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 58)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 58;
    }
    return _id;
}

// SIGNAL 0
void UserLayoutData::addToLayoutList(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4, qint32 _t5, QString _t6, QString _t7, QString _t8, QString _t9, qint32 _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void UserLayoutData::layoutComplited()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void UserLayoutData::deleteToLayoutList(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void UserLayoutData::refreshObj(qint32 _t1, QString _t2, qint32 _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void UserLayoutData::changeXYproperty(qint32 _t1, qint32 _t2, qint32 _t3, qint32 _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void UserLayoutData::changeSeqValueSignal(qint32 _t1, QString _t2, qint32 _t3, qint32 _t4, QString _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void UserLayoutData::getSelReg(qint32 _t1, qint32 _t2, QString _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void UserLayoutData::sendRCRS(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void UserLayoutData::sendSCRS(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7, QString _t8, QString _t9, QString _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void UserLayoutData::printReg(qint32 _t1, qint32 _t2, QString _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void UserLayoutData::printRegName(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void UserLayoutData::printToTerminal(QString _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void UserLayoutData::getFunctSignal(qint32 _t1, qint32 _t2, QString _t3, QString _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void UserLayoutData::getFunctRegSignal(QString _t1, qint32 _t2, QString _t3, qint32 _t4, qint32 _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void UserLayoutData::getDataTypeSignal(qint32 _t1, qint32 _t2, QString _t3, QString _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void UserLayoutData::getNoModifLenSignal(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void UserLayoutData::getLenSignal(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void UserLayoutData::getRangeSignal(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4, qint32 _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void UserLayoutData::getBckImageSignal(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void UserLayoutData::addLayoutPage(QString _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
