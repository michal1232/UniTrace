/****************************************************************************
** Meta object code from reading C++ file 'DataViewList.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/DataViewList.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'DataViewList.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DataViewList_t {
    QByteArrayData data[130];
    char stringdata0[1514];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DataViewList_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DataViewList_t qt_meta_stringdata_DataViewList = {
    {
QT_MOC_LITERAL(0, 0, 12), // "DataViewList"
QT_MOC_LITERAL(1, 13, 15), // "preItemAppended"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 16), // "postItemAppended"
QT_MOC_LITERAL(4, 47, 14), // "preItemRemoved"
QT_MOC_LITERAL(5, 62, 5), // "index"
QT_MOC_LITERAL(6, 68, 15), // "postItemRemoved"
QT_MOC_LITERAL(7, 84, 11), // "setItemData"
QT_MOC_LITERAL(8, 96, 5), // "value"
QT_MOC_LITERAL(9, 102, 4), // "role"
QT_MOC_LITERAL(10, 107, 14), // "itemQmlRemoved"
QT_MOC_LITERAL(11, 122, 14), // "sendRcrsSignal"
QT_MOC_LITERAL(12, 137, 12), // "logicChannel"
QT_MOC_LITERAL(13, 150, 7), // "regName"
QT_MOC_LITERAL(14, 158, 10), // "regAddress"
QT_MOC_LITERAL(15, 169, 6), // "nodeId"
QT_MOC_LITERAL(16, 176, 6), // "uartId"
QT_MOC_LITERAL(17, 183, 3), // "len"
QT_MOC_LITERAL(18, 187, 6), // "offset"
QT_MOC_LITERAL(19, 194, 14), // "sendScrsSignal"
QT_MOC_LITERAL(20, 209, 9), // "valueType"
QT_MOC_LITERAL(21, 219, 7), // "nameReg"
QT_MOC_LITERAL(22, 227, 9), // "sentValue"
QT_MOC_LITERAL(23, 237, 8), // "mulValue"
QT_MOC_LITERAL(24, 246, 11), // "refreshItem"
QT_MOC_LITERAL(25, 258, 8), // "setGroup"
QT_MOC_LITERAL(26, 267, 23), // "QVector<GroupViewItem>*"
QT_MOC_LITERAL(27, 291, 5), // "group"
QT_MOC_LITERAL(28, 297, 21), // "getmItemsEnViewSignal"
QT_MOC_LITERAL(29, 319, 10), // "protocolEn"
QT_MOC_LITERAL(30, 330, 4), // "LCEn"
QT_MOC_LITERAL(31, 335, 9), // "nameRegEn"
QT_MOC_LITERAL(32, 345, 11), // "valueTypeEn"
QT_MOC_LITERAL(33, 357, 10), // "minRangeEn"
QT_MOC_LITERAL(34, 368, 10), // "maxRangeEn"
QT_MOC_LITERAL(35, 379, 10), // "rwStatusEn"
QT_MOC_LITERAL(36, 390, 8), // "uartIdEn"
QT_MOC_LITERAL(37, 399, 5), // "lenEn"
QT_MOC_LITERAL(38, 405, 8), // "offsetEn"
QT_MOC_LITERAL(39, 414, 8), // "nodeIdEn"
QT_MOC_LITERAL(40, 423, 12), // "regAddressEn"
QT_MOC_LITERAL(41, 436, 10), // "getSelItem"
QT_MOC_LITERAL(42, 447, 4), // "page"
QT_MOC_LITERAL(43, 452, 5), // "point"
QT_MOC_LITERAL(44, 458, 13), // "DataViewItem*"
QT_MOC_LITERAL(45, 472, 4), // "item"
QT_MOC_LITERAL(46, 477, 12), // "setVauleType"
QT_MOC_LITERAL(47, 490, 12), // "currentIndex"
QT_MOC_LITERAL(48, 503, 3), // "row"
QT_MOC_LITERAL(49, 507, 9), // "setOffset"
QT_MOC_LITERAL(50, 517, 11), // "setRwStatus"
QT_MOC_LITERAL(51, 529, 11), // "setProtocol"
QT_MOC_LITERAL(52, 541, 5), // "setLC"
QT_MOC_LITERAL(53, 547, 15), // "toggleSetSignal"
QT_MOC_LITERAL(54, 563, 21), // "getDefaultValueSignal"
QT_MOC_LITERAL(55, 585, 8), // "defValue"
QT_MOC_LITERAL(56, 594, 20), // "getDescriptionSignal"
QT_MOC_LITERAL(57, 615, 4), // "desc"
QT_MOC_LITERAL(58, 620, 10), // "refreshRow"
QT_MOC_LITERAL(59, 631, 6), // "selRow"
QT_MOC_LITERAL(60, 638, 8), // "deselRow"
QT_MOC_LITERAL(61, 647, 12), // "getLenSignal"
QT_MOC_LITERAL(62, 660, 3), // "reg"
QT_MOC_LITERAL(63, 664, 14), // "getRangeSignal"
QT_MOC_LITERAL(64, 679, 3), // "min"
QT_MOC_LITERAL(65, 683, 3), // "max"
QT_MOC_LITERAL(66, 687, 14), // "setNewDataToLC"
QT_MOC_LITERAL(67, 702, 8), // "protocol"
QT_MOC_LITERAL(68, 711, 18), // "changeProtocolToLC"
QT_MOC_LITERAL(69, 730, 14), // "getIdRegSignal"
QT_MOC_LITERAL(70, 745, 6), // "idList"
QT_MOC_LITERAL(71, 752, 10), // "appendItem"
QT_MOC_LITERAL(72, 763, 2), // "lc"
QT_MOC_LITERAL(73, 766, 20), // "removeCompletedItems"
QT_MOC_LITERAL(74, 787, 9), // "deleteAll"
QT_MOC_LITERAL(75, 797, 9), // "upSelItem"
QT_MOC_LITERAL(76, 807, 11), // "downSelItem"
QT_MOC_LITERAL(77, 819, 11), // "regroupItem"
QT_MOC_LITERAL(78, 831, 14), // "editItemViewEn"
QT_MOC_LITERAL(79, 846, 5), // "enVal"
QT_MOC_LITERAL(80, 852, 3), // "num"
QT_MOC_LITERAL(81, 856, 12), // "editItemSent"
QT_MOC_LITERAL(82, 869, 5), // "input"
QT_MOC_LITERAL(83, 875, 11), // "editItemSet"
QT_MOC_LITERAL(84, 887, 14), // "editItemSetAll"
QT_MOC_LITERAL(85, 902, 16), // "editItemMulValue"
QT_MOC_LITERAL(86, 919, 18), // "editItemNewProject"
QT_MOC_LITERAL(87, 938, 6), // "column"
QT_MOC_LITERAL(88, 945, 23), // "editItemProtocolChanged"
QT_MOC_LITERAL(89, 969, 14), // "saveItemToFile"
QT_MOC_LITERAL(90, 984, 10), // "fileSource"
QT_MOC_LITERAL(91, 995, 14), // "loadItemToFile"
QT_MOC_LITERAL(92, 1010, 11), // "openProject"
QT_MOC_LITERAL(93, 1022, 12), // "saveReadData"
QT_MOC_LITERAL(94, 1035, 12), // "loadSendData"
QT_MOC_LITERAL(95, 1048, 12), // "sendSelected"
QT_MOC_LITERAL(96, 1061, 7), // "sendAll"
QT_MOC_LITERAL(97, 1069, 13), // "writeSelected"
QT_MOC_LITERAL(98, 1083, 8), // "writeAll"
QT_MOC_LITERAL(99, 1092, 15), // "saveRequestAdam"
QT_MOC_LITERAL(100, 1108, 22), // "DATA_UART_ADAM_PACKET*"
QT_MOC_LITERAL(101, 1131, 10), // "adamPacekt"
QT_MOC_LITERAL(102, 1142, 17), // "saveRequestModBus"
QT_MOC_LITERAL(103, 1160, 17), // "MODBUS_RX_STRUCT*"
QT_MOC_LITERAL(104, 1178, 12), // "modBusPacket"
QT_MOC_LITERAL(105, 1191, 15), // "saveRequestSCPI"
QT_MOC_LITERAL(106, 1207, 8), // "SCPIdata"
QT_MOC_LITERAL(107, 1216, 10), // "setSelItem"
QT_MOC_LITERAL(108, 1227, 13), // "getIndexOfReg"
QT_MOC_LITERAL(109, 1241, 12), // "getValueType"
QT_MOC_LITERAL(110, 1254, 9), // "getOffset"
QT_MOC_LITERAL(111, 1264, 11), // "getRwStatus"
QT_MOC_LITERAL(112, 1276, 11), // "getProtocol"
QT_MOC_LITERAL(113, 1288, 5), // "getLc"
QT_MOC_LITERAL(114, 1294, 14), // "setPropRegName"
QT_MOC_LITERAL(115, 1309, 15), // "setGroupRegName"
QT_MOC_LITERAL(116, 1325, 9), // "setSetReg"
QT_MOC_LITERAL(117, 1335, 3), // "set"
QT_MOC_LITERAL(118, 1339, 9), // "toggleSet"
QT_MOC_LITERAL(119, 1349, 18), // "setNewDataToLCSlot"
QT_MOC_LITERAL(120, 1368, 22), // "changeProtocolToLCSlot"
QT_MOC_LITERAL(121, 1391, 19), // "getDefaultValueSlot"
QT_MOC_LITERAL(122, 1411, 18), // "getDescriptionSlot"
QT_MOC_LITERAL(123, 1430, 10), // "getLenSlot"
QT_MOC_LITERAL(124, 1441, 12), // "getRangeSlot"
QT_MOC_LITERAL(125, 1454, 19), // "getmItemsEnViewSlot"
QT_MOC_LITERAL(126, 1474, 10), // "rowChanged"
QT_MOC_LITERAL(127, 1485, 8), // "position"
QT_MOC_LITERAL(128, 1494, 10), // "rowDeleted"
QT_MOC_LITERAL(129, 1505, 8) // "getIdReg"

    },
    "DataViewList\0preItemAppended\0\0"
    "postItemAppended\0preItemRemoved\0index\0"
    "postItemRemoved\0setItemData\0value\0"
    "role\0itemQmlRemoved\0sendRcrsSignal\0"
    "logicChannel\0regName\0regAddress\0nodeId\0"
    "uartId\0len\0offset\0sendScrsSignal\0"
    "valueType\0nameReg\0sentValue\0mulValue\0"
    "refreshItem\0setGroup\0QVector<GroupViewItem>*\0"
    "group\0getmItemsEnViewSignal\0protocolEn\0"
    "LCEn\0nameRegEn\0valueTypeEn\0minRangeEn\0"
    "maxRangeEn\0rwStatusEn\0uartIdEn\0lenEn\0"
    "offsetEn\0nodeIdEn\0regAddressEn\0"
    "getSelItem\0page\0point\0DataViewItem*\0"
    "item\0setVauleType\0currentIndex\0row\0"
    "setOffset\0setRwStatus\0setProtocol\0"
    "setLC\0toggleSetSignal\0getDefaultValueSignal\0"
    "defValue\0getDescriptionSignal\0desc\0"
    "refreshRow\0selRow\0deselRow\0getLenSignal\0"
    "reg\0getRangeSignal\0min\0max\0setNewDataToLC\0"
    "protocol\0changeProtocolToLC\0getIdRegSignal\0"
    "idList\0appendItem\0lc\0removeCompletedItems\0"
    "deleteAll\0upSelItem\0downSelItem\0"
    "regroupItem\0editItemViewEn\0enVal\0num\0"
    "editItemSent\0input\0editItemSet\0"
    "editItemSetAll\0editItemMulValue\0"
    "editItemNewProject\0column\0"
    "editItemProtocolChanged\0saveItemToFile\0"
    "fileSource\0loadItemToFile\0openProject\0"
    "saveReadData\0loadSendData\0sendSelected\0"
    "sendAll\0writeSelected\0writeAll\0"
    "saveRequestAdam\0DATA_UART_ADAM_PACKET*\0"
    "adamPacekt\0saveRequestModBus\0"
    "MODBUS_RX_STRUCT*\0modBusPacket\0"
    "saveRequestSCPI\0SCPIdata\0setSelItem\0"
    "getIndexOfReg\0getValueType\0getOffset\0"
    "getRwStatus\0getProtocol\0getLc\0"
    "setPropRegName\0setGroupRegName\0setSetReg\0"
    "set\0toggleSet\0setNewDataToLCSlot\0"
    "changeProtocolToLCSlot\0getDefaultValueSlot\0"
    "getDescriptionSlot\0getLenSlot\0"
    "getRangeSlot\0getmItemsEnViewSlot\0"
    "rowChanged\0position\0rowDeleted\0getIdReg"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DataViewList[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      72,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      28,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  374,    2, 0x06 /* Public */,
       3,    0,  375,    2, 0x06 /* Public */,
       4,    1,  376,    2, 0x06 /* Public */,
       6,    0,  379,    2, 0x06 /* Public */,
       7,    3,  380,    2, 0x06 /* Public */,
      10,    1,  387,    2, 0x06 /* Public */,
      11,    7,  390,    2, 0x06 /* Public */,
      19,   10,  405,    2, 0x06 /* Public */,
      24,    0,  426,    2, 0x06 /* Public */,
      25,    1,  427,    2, 0x06 /* Public */,
      28,   12,  430,    2, 0x06 /* Public */,
      41,    3,  455,    2, 0x06 /* Public */,
      46,    2,  462,    2, 0x06 /* Public */,
      49,    2,  467,    2, 0x06 /* Public */,
      50,    2,  472,    2, 0x06 /* Public */,
      51,    2,  477,    2, 0x06 /* Public */,
      52,    2,  482,    2, 0x06 /* Public */,
      53,    2,  487,    2, 0x06 /* Public */,
      54,    2,  492,    2, 0x06 /* Public */,
      56,    2,  497,    2, 0x06 /* Public */,
      58,    1,  502,    2, 0x06 /* Public */,
      59,    1,  505,    2, 0x06 /* Public */,
      60,    1,  508,    2, 0x06 /* Public */,
      61,    4,  511,    2, 0x06 /* Public */,
      63,    5,  520,    2, 0x06 /* Public */,
      66,    2,  531,    2, 0x06 /* Public */,
      68,    2,  536,    2, 0x06 /* Public */,
      69,    1,  541,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      71,    2,  544,    2, 0x0a /* Public */,
      73,    1,  549,    2, 0x0a /* Public */,
      75,    0,  552,    2, 0x0a /* Public */,
      76,    0,  553,    2, 0x0a /* Public */,
      77,    0,  554,    2, 0x0a /* Public */,
      78,    2,  555,    2, 0x0a /* Public */,
      81,    2,  560,    2, 0x0a /* Public */,
      83,    2,  565,    2, 0x0a /* Public */,
      84,    1,  570,    2, 0x0a /* Public */,
      85,    2,  573,    2, 0x0a /* Public */,
      86,    3,  578,    2, 0x0a /* Public */,
      88,    2,  585,    2, 0x0a /* Public */,
      89,    1,  590,    2, 0x0a /* Public */,
      91,    4,  593,    2, 0x0a /* Public */,
      93,    1,  602,    2, 0x0a /* Public */,
      94,    1,  605,    2, 0x0a /* Public */,
      95,    0,  608,    2, 0x0a /* Public */,
      96,    0,  609,    2, 0x0a /* Public */,
      97,    0,  610,    2, 0x0a /* Public */,
      98,    0,  611,    2, 0x0a /* Public */,
      99,    1,  612,    2, 0x0a /* Public */,
     102,    2,  615,    2, 0x0a /* Public */,
     105,    3,  620,    2, 0x0a /* Public */,
     107,    3,  627,    2, 0x0a /* Public */,
     108,    1,  634,    2, 0x0a /* Public */,
     109,    1,  637,    2, 0x0a /* Public */,
     110,    1,  640,    2, 0x0a /* Public */,
     111,    1,  643,    2, 0x0a /* Public */,
     112,    1,  646,    2, 0x0a /* Public */,
     113,    1,  649,    2, 0x0a /* Public */,
     114,    1,  652,    2, 0x0a /* Public */,
     115,    1,  655,    2, 0x0a /* Public */,
     116,    2,  658,    2, 0x0a /* Public */,
     118,    1,  663,    2, 0x0a /* Public */,
     119,    2,  666,    2, 0x0a /* Public */,
     120,    2,  671,    2, 0x0a /* Public */,
     121,    1,  676,    2, 0x0a /* Public */,
     122,    1,  679,    2, 0x0a /* Public */,
     123,    3,  682,    2, 0x0a /* Public */,
     124,    3,  689,    2, 0x0a /* Public */,
     125,    0,  696,    2, 0x0a /* Public */,
     126,    2,  697,    2, 0x0a /* Public */,
     128,    1,  702,    2, 0x0a /* Public */,
     129,    2,  705,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QVariant, QMetaType::UInt,    5,    8,    9,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   12,   13,   14,   15,   16,   17,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   12,   20,   21,   22,   14,   15,   16,   17,   18,   23,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   29,   30,   31,   32,   33,   34,   35,   36,   37,   38,   39,   40,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 44,   42,   43,   45,
    QMetaType::Void, QMetaType::Int, QMetaType::UInt,   47,   48,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt,   47,   48,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt,   47,   48,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt,   47,   48,
    QMetaType::Void, QMetaType::UInt, QMetaType::UInt,   47,   48,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   48,    8,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   48,   55,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   48,   57,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int,   62,   42,   17,   43,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   62,   42,   64,   65,   43,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   12,   67,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   12,   67,
    QMetaType::Void, QMetaType::QStringList,   70,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   72,   48,
    QMetaType::Void, QMetaType::Bool,   74,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Int,   79,   80,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   48,   82,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   48,   82,
    QMetaType::Void, QMetaType::Bool,   82,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   48,   82,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   48,   87,   82,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   12,   67,
    QMetaType::Void, QMetaType::QString,   90,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   90,   12,   67,   92,
    QMetaType::Void, QMetaType::QString,   90,
    QMetaType::Void, QMetaType::QString,   90,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 100,  101,
    QMetaType::Void, 0x80000000 | 103, QMetaType::QString,  104,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,  106,   12,   13,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,   42,   43,   13,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::UInt,   48,
    QMetaType::Void, QMetaType::UInt,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   48,  117,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   12,   67,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   12,   67,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   42,   13,   43,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,   42,   13,   43,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,  127,    8,
    QMetaType::Void, QMetaType::Int,  127,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   12,   21,

       0        // eod
};

void DataViewList::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DataViewList *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->preItemAppended(); break;
        case 1: _t->postItemAppended(); break;
        case 2: _t->preItemRemoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->postItemRemoved(); break;
        case 4: _t->setItemData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QVariant(*)>(_a[2])),(*reinterpret_cast< quint32(*)>(_a[3]))); break;
        case 5: _t->itemQmlRemoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->sendRcrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 7: _t->sendScrsSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 8: _t->refreshItem(); break;
        case 9: _t->setGroup((*reinterpret_cast< QVector<GroupViewItem>*(*)>(_a[1]))); break;
        case 10: _t->getmItemsEnViewSignal((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])),(*reinterpret_cast< bool(*)>(_a[11])),(*reinterpret_cast< bool(*)>(_a[12]))); break;
        case 11: _t->getSelItem((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< DataViewItem*(*)>(_a[3]))); break;
        case 12: _t->setVauleType((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2]))); break;
        case 13: _t->setOffset((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2]))); break;
        case 14: _t->setRwStatus((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2]))); break;
        case 15: _t->setProtocol((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2]))); break;
        case 16: _t->setLC((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint32(*)>(_a[2]))); break;
        case 17: _t->toggleSetSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 18: _t->getDefaultValueSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 19: _t->getDescriptionSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 20: _t->refreshRow((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 21: _t->selRow((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 22: _t->deselRow((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 23: _t->getLenSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4]))); break;
        case 24: _t->getRangeSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5]))); break;
        case 25: _t->setNewDataToLC((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 26: _t->changeProtocolToLC((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 27: _t->getIdRegSignal((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 28: _t->appendItem((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 29: _t->removeCompletedItems((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->upSelItem(); break;
        case 31: _t->downSelItem(); break;
        case 32: _t->regroupItem(); break;
        case 33: _t->editItemViewEn((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 34: _t->editItemSent((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 35: _t->editItemSet((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 36: _t->editItemSetAll((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->editItemMulValue((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 38: _t->editItemNewProject((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 39: _t->editItemProtocolChanged((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 40: _t->saveItemToFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 41: _t->loadItemToFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 42: _t->saveReadData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 43: _t->loadSendData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 44: _t->sendSelected(); break;
        case 45: _t->sendAll(); break;
        case 46: _t->writeSelected(); break;
        case 47: _t->writeAll(); break;
        case 48: _t->saveRequestAdam((*reinterpret_cast< DATA_UART_ADAM_PACKET*(*)>(_a[1]))); break;
        case 49: _t->saveRequestModBus((*reinterpret_cast< MODBUS_RX_STRUCT*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 50: _t->saveRequestSCPI((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 51: _t->setSelItem((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 52: _t->getIndexOfReg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 53: _t->getValueType((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 54: _t->getOffset((*reinterpret_cast< quint32(*)>(_a[1]))); break;
        case 55: _t->getRwStatus((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 56: _t->getProtocol((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 57: _t->getLc((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 58: _t->setPropRegName((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 59: _t->setGroupRegName((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 60: _t->setSetReg((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 61: _t->toggleSet((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 62: _t->setNewDataToLCSlot((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 63: _t->changeProtocolToLCSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 64: _t->getDefaultValueSlot((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 65: _t->getDescriptionSlot((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 66: _t->getLenSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 67: _t->getRangeSlot((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3]))); break;
        case 68: _t->getmItemsEnViewSlot(); break;
        case 69: _t->rowChanged((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 70: _t->rowDeleted((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 71: _t->getIdReg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (DataViewList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::preItemAppended)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::postItemAppended)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::preItemRemoved)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::postItemRemoved)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(int , QVariant , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setItemData)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::itemQmlRemoved)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::sendRcrsSignal)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , QString , QString , QString , QString , QString , QString , QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::sendScrsSignal)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::refreshItem)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(QVector<GroupViewItem> * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setGroup)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(bool , bool , bool , bool , bool , bool , bool , bool , bool , bool , bool , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getmItemsEnViewSignal)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , qint32 , DataViewItem * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getSelItem)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setVauleType)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(quint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setOffset)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(quint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setRwStatus)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(quint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setProtocol)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(quint32 , quint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setLC)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::toggleSetSignal)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getDefaultValueSignal)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getDescriptionSignal)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::refreshRow)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::selRow)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::deselRow)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(QString , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getLenSignal)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(QString , qint32 , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getRangeSignal)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::setNewDataToLC)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::changeProtocolToLC)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (DataViewList::*)(QStringList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataViewList::getIdRegSignal)) {
                *result = 27;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject DataViewList::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_DataViewList.data,
    qt_meta_data_DataViewList,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *DataViewList::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DataViewList::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DataViewList.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int DataViewList::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 72)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 72;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 72)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 72;
    }
    return _id;
}

// SIGNAL 0
void DataViewList::preItemAppended()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void DataViewList::postItemAppended()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void DataViewList::preItemRemoved(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DataViewList::postItemRemoved()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void DataViewList::setItemData(int _t1, QVariant _t2, quint32 _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void DataViewList::itemQmlRemoved(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void DataViewList::sendRcrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void DataViewList::sendScrsSignal(qint32 _t1, QString _t2, QString _t3, QString _t4, QString _t5, QString _t6, QString _t7, QString _t8, QString _t9, QString _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void DataViewList::refreshItem()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void DataViewList::setGroup(QVector<GroupViewItem> * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void DataViewList::getmItemsEnViewSignal(bool _t1, bool _t2, bool _t3, bool _t4, bool _t5, bool _t6, bool _t7, bool _t8, bool _t9, bool _t10, bool _t11, bool _t12)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t11))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t12))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void DataViewList::getSelItem(qint32 _t1, qint32 _t2, DataViewItem * _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void DataViewList::setVauleType(qint32 _t1, quint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void DataViewList::setOffset(quint32 _t1, quint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void DataViewList::setRwStatus(quint32 _t1, quint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void DataViewList::setProtocol(quint32 _t1, quint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void DataViewList::setLC(quint32 _t1, quint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void DataViewList::toggleSetSignal(qint32 _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void DataViewList::getDefaultValueSignal(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void DataViewList::getDescriptionSignal(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void DataViewList::refreshRow(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void DataViewList::selRow(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void DataViewList::deselRow(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void DataViewList::getLenSignal(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void DataViewList::getRangeSignal(QString _t1, qint32 _t2, qint32 _t3, qint32 _t4, qint32 _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void DataViewList::setNewDataToLC(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void DataViewList::changeProtocolToLC(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void DataViewList::getIdRegSignal(QStringList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
