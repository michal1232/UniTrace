/****************************************************************************
** Meta object code from reading C++ file 'treeviewmodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/treeviewmodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'treeviewmodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TreeViewModel_t {
    QByteArrayData data[21];
    char stringdata0[215];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TreeViewModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TreeViewModel_t qt_meta_stringdata_TreeViewModel = {
    {
QT_MOC_LITERAL(0, 0, 13), // "TreeViewModel"
QT_MOC_LITERAL(1, 14, 12), // "filterSignal"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 10), // "filtString"
QT_MOC_LITERAL(4, 39, 11), // "addToFilter"
QT_MOC_LITERAL(5, 51, 11), // "expandChild"
QT_MOC_LITERAL(6, 63, 11), // "QModelIndex"
QT_MOC_LITERAL(7, 75, 5), // "index"
QT_MOC_LITERAL(8, 81, 11), // "colapsChild"
QT_MOC_LITERAL(9, 93, 10), // "cleanModel"
QT_MOC_LITERAL(10, 104, 11), // "insertGroup"
QT_MOC_LITERAL(11, 116, 23), // "QVector<GroupViewItem>*"
QT_MOC_LITERAL(12, 140, 5), // "group"
QT_MOC_LITERAL(13, 146, 14), // "filterSelected"
QT_MOC_LITERAL(14, 161, 6), // "index0"
QT_MOC_LITERAL(15, 168, 6), // "index1"
QT_MOC_LITERAL(16, 175, 6), // "index2"
QT_MOC_LITERAL(17, 182, 6), // "index3"
QT_MOC_LITERAL(18, 189, 7), // "checked"
QT_MOC_LITERAL(19, 197, 10), // "expandSlot"
QT_MOC_LITERAL(20, 208, 6) // "expand"

    },
    "TreeViewModel\0filterSignal\0\0filtString\0"
    "addToFilter\0expandChild\0QModelIndex\0"
    "index\0colapsChild\0cleanModel\0insertGroup\0"
    "QVector<GroupViewItem>*\0group\0"
    "filterSelected\0index0\0index1\0index2\0"
    "index3\0checked\0expandSlot\0expand"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TreeViewModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   49,    2, 0x06 /* Public */,
       5,    1,   54,    2, 0x06 /* Public */,
       8,    1,   57,    2, 0x06 /* Public */,
       9,    0,   60,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    1,   61,    2, 0x0a /* Public */,
      13,    5,   64,    2, 0x0a /* Public */,
      19,    1,   75,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Bool,    3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 6, 0x80000000 | 6, 0x80000000 | 6, 0x80000000 | 6, QMetaType::Bool,   14,   15,   16,   17,   18,
    QMetaType::Void, QMetaType::Bool,   20,

       0        // eod
};

void TreeViewModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TreeViewModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->filterSignal((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: _t->expandChild((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 2: _t->colapsChild((*reinterpret_cast< QModelIndex(*)>(_a[1]))); break;
        case 3: _t->cleanModel(); break;
        case 4: _t->insertGroup((*reinterpret_cast< QVector<GroupViewItem>*(*)>(_a[1]))); break;
        case 5: _t->filterSelected((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2])),(*reinterpret_cast< const QModelIndex(*)>(_a[3])),(*reinterpret_cast< const QModelIndex(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5]))); break;
        case 6: _t->expandSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TreeViewModel::*)(QString , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TreeViewModel::filterSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TreeViewModel::*)(QModelIndex );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TreeViewModel::expandChild)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TreeViewModel::*)(QModelIndex );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TreeViewModel::colapsChild)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (TreeViewModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TreeViewModel::cleanModel)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject TreeViewModel::staticMetaObject = { {
    QMetaObject::SuperData::link<QStandardItemModel::staticMetaObject>(),
    qt_meta_stringdata_TreeViewModel.data,
    qt_meta_data_TreeViewModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TreeViewModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TreeViewModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TreeViewModel.stringdata0))
        return static_cast<void*>(this);
    return QStandardItemModel::qt_metacast(_clname);
}

int TreeViewModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QStandardItemModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void TreeViewModel::filterSignal(QString _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TreeViewModel::expandChild(QModelIndex _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TreeViewModel::colapsChild(QModelIndex _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void TreeViewModel::cleanModel()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
