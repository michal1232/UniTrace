/****************************************************************************
** Meta object code from reading C++ file 'radialbar.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/radialbar.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'radialbar.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RadialBar_t {
    QByteArrayData data[38];
    char stringdata0[483];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RadialBar_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RadialBar_t qt_meta_stringdata_RadialBar = {
    {
QT_MOC_LITERAL(0, 0, 9), // "RadialBar"
QT_MOC_LITERAL(1, 10, 11), // "sizeChanged"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 17), // "startAngleChanged"
QT_MOC_LITERAL(4, 41, 16), // "spanAngleChanged"
QT_MOC_LITERAL(5, 58, 15), // "minValueChanged"
QT_MOC_LITERAL(6, 74, 15), // "maxValueChanged"
QT_MOC_LITERAL(7, 90, 12), // "valueChanged"
QT_MOC_LITERAL(8, 103, 16), // "dialWidthChanged"
QT_MOC_LITERAL(9, 120, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(10, 143, 22), // "foregroundColorChanged"
QT_MOC_LITERAL(11, 166, 20), // "progressColorChanged"
QT_MOC_LITERAL(12, 187, 16), // "textColorChanged"
QT_MOC_LITERAL(13, 204, 17), // "suffixTextChanged"
QT_MOC_LITERAL(14, 222, 15), // "penStyleChanged"
QT_MOC_LITERAL(15, 238, 15), // "dialTypeChanged"
QT_MOC_LITERAL(16, 254, 15), // "textFontChanged"
QT_MOC_LITERAL(17, 270, 4), // "size"
QT_MOC_LITERAL(18, 275, 10), // "startAngle"
QT_MOC_LITERAL(19, 286, 9), // "spanAngle"
QT_MOC_LITERAL(20, 296, 8), // "minValue"
QT_MOC_LITERAL(21, 305, 8), // "maxValue"
QT_MOC_LITERAL(22, 314, 5), // "value"
QT_MOC_LITERAL(23, 320, 9), // "dialWidth"
QT_MOC_LITERAL(24, 330, 15), // "backgroundColor"
QT_MOC_LITERAL(25, 346, 15), // "foregroundColor"
QT_MOC_LITERAL(26, 362, 13), // "progressColor"
QT_MOC_LITERAL(27, 376, 9), // "textColor"
QT_MOC_LITERAL(28, 386, 10), // "suffixText"
QT_MOC_LITERAL(29, 397, 8), // "showText"
QT_MOC_LITERAL(30, 406, 8), // "penStyle"
QT_MOC_LITERAL(31, 415, 15), // "Qt::PenCapStyle"
QT_MOC_LITERAL(32, 431, 8), // "dialType"
QT_MOC_LITERAL(33, 440, 8), // "DialType"
QT_MOC_LITERAL(34, 449, 8), // "textFont"
QT_MOC_LITERAL(35, 458, 8), // "FullDial"
QT_MOC_LITERAL(36, 467, 8), // "MinToMax"
QT_MOC_LITERAL(37, 476, 6) // "NoDial"

    },
    "RadialBar\0sizeChanged\0\0startAngleChanged\0"
    "spanAngleChanged\0minValueChanged\0"
    "maxValueChanged\0valueChanged\0"
    "dialWidthChanged\0backgroundColorChanged\0"
    "foregroundColorChanged\0progressColorChanged\0"
    "textColorChanged\0suffixTextChanged\0"
    "penStyleChanged\0dialTypeChanged\0"
    "textFontChanged\0size\0startAngle\0"
    "spanAngle\0minValue\0maxValue\0value\0"
    "dialWidth\0backgroundColor\0foregroundColor\0"
    "progressColor\0textColor\0suffixText\0"
    "showText\0penStyle\0Qt::PenCapStyle\0"
    "dialType\0DialType\0textFont\0FullDial\0"
    "MinToMax\0NoDial"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RadialBar[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
      16,  104, // properties
       1,  168, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x06 /* Public */,
       3,    0,   90,    2, 0x06 /* Public */,
       4,    0,   91,    2, 0x06 /* Public */,
       5,    0,   92,    2, 0x06 /* Public */,
       6,    0,   93,    2, 0x06 /* Public */,
       7,    0,   94,    2, 0x06 /* Public */,
       8,    0,   95,    2, 0x06 /* Public */,
       9,    0,   96,    2, 0x06 /* Public */,
      10,    0,   97,    2, 0x06 /* Public */,
      11,    0,   98,    2, 0x06 /* Public */,
      12,    0,   99,    2, 0x06 /* Public */,
      13,    0,  100,    2, 0x06 /* Public */,
      14,    0,  101,    2, 0x06 /* Public */,
      15,    0,  102,    2, 0x06 /* Public */,
      16,    0,  103,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      17, QMetaType::QReal, 0x00495103,
      18, QMetaType::QReal, 0x00495103,
      19, QMetaType::QReal, 0x00495103,
      20, QMetaType::QReal, 0x00495103,
      21, QMetaType::QReal, 0x00495103,
      22, QMetaType::QReal, 0x00495103,
      23, QMetaType::Int, 0x00495103,
      24, QMetaType::QColor, 0x00495103,
      25, QMetaType::QColor, 0x00495103,
      26, QMetaType::QColor, 0x00495103,
      27, QMetaType::QColor, 0x00495103,
      28, QMetaType::QString, 0x00495103,
      29, QMetaType::Bool, 0x00095103,
      30, 0x80000000 | 31, 0x0049510b,
      32, 0x80000000 | 33, 0x0049510b,
      34, QMetaType::QFont, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,
       8,
       9,
      10,
      11,
       0,
      12,
      13,
      14,

 // enums: name, alias, flags, count, data
      33,   33, 0x0,    3,  173,

 // enum data: key, value
      35, uint(RadialBar::FullDial),
      36, uint(RadialBar::MinToMax),
      37, uint(RadialBar::NoDial),

       0        // eod
};

void RadialBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<RadialBar *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sizeChanged(); break;
        case 1: _t->startAngleChanged(); break;
        case 2: _t->spanAngleChanged(); break;
        case 3: _t->minValueChanged(); break;
        case 4: _t->maxValueChanged(); break;
        case 5: _t->valueChanged(); break;
        case 6: _t->dialWidthChanged(); break;
        case 7: _t->backgroundColorChanged(); break;
        case 8: _t->foregroundColorChanged(); break;
        case 9: _t->progressColorChanged(); break;
        case 10: _t->textColorChanged(); break;
        case 11: _t->suffixTextChanged(); break;
        case 12: _t->penStyleChanged(); break;
        case 13: _t->dialTypeChanged(); break;
        case 14: _t->textFontChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::sizeChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::startAngleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::spanAngleChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::minValueChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::maxValueChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::valueChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::dialWidthChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::backgroundColorChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::foregroundColorChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::progressColorChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::textColorChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::suffixTextChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::penStyleChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::dialTypeChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (RadialBar::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RadialBar::textFontChanged)) {
                *result = 14;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<RadialBar *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->getSize(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->getStartAngle(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->getSpanAngle(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->getMinValue(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->getMaxValue(); break;
        case 5: *reinterpret_cast< qreal*>(_v) = _t->getValue(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->getDialWidth(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->getBackgroundColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getForegroundColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getProgressColor(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getTextColor(); break;
        case 11: *reinterpret_cast< QString*>(_v) = _t->getSuffixText(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->isShowText(); break;
        case 13: *reinterpret_cast< Qt::PenCapStyle*>(_v) = _t->getPenStyle(); break;
        case 14: *reinterpret_cast< DialType*>(_v) = _t->getDialType(); break;
        case 15: *reinterpret_cast< QFont*>(_v) = _t->getTextFont(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<RadialBar *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSize(*reinterpret_cast< qreal*>(_v)); break;
        case 1: _t->setStartAngle(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setSpanAngle(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setMinValue(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setMaxValue(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setValue(*reinterpret_cast< qreal*>(_v)); break;
        case 6: _t->setDialWidth(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setProgressColor(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setSuffixText(*reinterpret_cast< QString*>(_v)); break;
        case 12: _t->setShowText(*reinterpret_cast< bool*>(_v)); break;
        case 13: _t->setPenStyle(*reinterpret_cast< Qt::PenCapStyle*>(_v)); break;
        case 14: _t->setDialType(*reinterpret_cast< DialType*>(_v)); break;
        case 15: _t->setTextFont(*reinterpret_cast< QFont*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject RadialBar::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickPaintedItem::staticMetaObject>(),
    qt_meta_stringdata_RadialBar.data,
    qt_meta_data_RadialBar,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RadialBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RadialBar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RadialBar.stringdata0))
        return static_cast<void*>(this);
    return QQuickPaintedItem::qt_metacast(_clname);
}

int RadialBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 16;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void RadialBar::sizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void RadialBar::startAngleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void RadialBar::spanAngleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void RadialBar::minValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void RadialBar::maxValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void RadialBar::valueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void RadialBar::dialWidthChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void RadialBar::backgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void RadialBar::foregroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void RadialBar::progressColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void RadialBar::textColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void RadialBar::suffixTextChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void RadialBar::penStyleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void RadialBar::dialTypeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void RadialBar::textFontChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
