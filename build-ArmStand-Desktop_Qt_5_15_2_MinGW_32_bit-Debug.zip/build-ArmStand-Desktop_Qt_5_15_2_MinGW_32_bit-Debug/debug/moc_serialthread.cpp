/****************************************************************************
** Meta object code from reading C++ file 'serialthread.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/serialthread.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serialthread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SerialThread_t {
    QByteArrayData data[85];
    char stringdata0[1072];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SerialThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SerialThread_t qt_meta_stringdata_SerialThread = {
    {
QT_MOC_LITERAL(0, 0, 12), // "SerialThread"
QT_MOC_LITERAL(1, 13, 19), // "printPortNameSignal"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 9), // "outString"
QT_MOC_LITERAL(4, 44, 16), // "printPortAvaible"
QT_MOC_LITERAL(5, 61, 12), // "logicChannel"
QT_MOC_LITERAL(6, 74, 11), // "avaiblePort"
QT_MOC_LITERAL(7, 86, 17), // "addSerialLCSignal"
QT_MOC_LITERAL(8, 104, 21), // "cleanRxTerminalSignal"
QT_MOC_LITERAL(9, 126, 15), // "printDataSignal"
QT_MOC_LITERAL(10, 142, 8), // "inString"
QT_MOC_LITERAL(11, 151, 13), // "printDataByte"
QT_MOC_LITERAL(12, 165, 6), // "inData"
QT_MOC_LITERAL(13, 172, 3), // "src"
QT_MOC_LITERAL(14, 176, 17), // "getProtocolSignal"
QT_MOC_LITERAL(15, 194, 8), // "protocol"
QT_MOC_LITERAL(16, 203, 15), // "recievedAdamMsg"
QT_MOC_LITERAL(17, 219, 22), // "DATA_UART_ADAM_PACKET*"
QT_MOC_LITERAL(18, 242, 8), // "rcv_data"
QT_MOC_LITERAL(19, 251, 17), // "recievedModBusMsg"
QT_MOC_LITERAL(20, 269, 17), // "MODBUS_RX_STRUCT*"
QT_MOC_LITERAL(21, 287, 15), // "recievedSCPIMsg"
QT_MOC_LITERAL(22, 303, 8), // "SCPIdata"
QT_MOC_LITERAL(23, 312, 7), // "regName"
QT_MOC_LITERAL(24, 320, 20), // "getNumOfSerialSignal"
QT_MOC_LITERAL(25, 341, 11), // "numOfSerial"
QT_MOC_LITERAL(26, 353, 21), // "getInfoOfSerialSignal"
QT_MOC_LITERAL(27, 375, 8), // "fileName"
QT_MOC_LITERAL(28, 384, 8), // "baudRate"
QT_MOC_LITERAL(29, 393, 10), // "dataLenght"
QT_MOC_LITERAL(30, 404, 6), // "parity"
QT_MOC_LITERAL(31, 411, 7), // "stopBit"
QT_MOC_LITERAL(32, 419, 10), // "bufferSize"
QT_MOC_LITERAL(33, 430, 13), // "modbusTimeout"
QT_MOC_LITERAL(34, 444, 23), // "editItemProtocolChanged"
QT_MOC_LITERAL(35, 468, 21), // "getStringDataInSignal"
QT_MOC_LITERAL(36, 490, 6), // "dataIn"
QT_MOC_LITERAL(37, 497, 20), // "getTermLastMsgSignal"
QT_MOC_LITERAL(38, 518, 8), // "lastData"
QT_MOC_LITERAL(39, 527, 8), // "addSlots"
QT_MOC_LITERAL(40, 536, 8), // "portName"
QT_MOC_LITERAL(41, 545, 10), // "startSlots"
QT_MOC_LITERAL(42, 556, 9), // "stopSlots"
QT_MOC_LITERAL(43, 566, 11), // "restartSlot"
QT_MOC_LITERAL(44, 578, 15), // "readSerialSlots"
QT_MOC_LITERAL(45, 594, 16), // "writeSerialSlots"
QT_MOC_LITERAL(46, 611, 8), // "sendData"
QT_MOC_LITERAL(47, 620, 15), // "getPortNameSlot"
QT_MOC_LITERAL(48, 636, 11), // "getProtocol"
QT_MOC_LITERAL(49, 648, 11), // "setProtocol"
QT_MOC_LITERAL(50, 660, 15), // "getSerialStatus"
QT_MOC_LITERAL(51, 676, 19), // "getStringDataInSlot"
QT_MOC_LITERAL(52, 696, 19), // "clrStringDataInSlot"
QT_MOC_LITERAL(53, 716, 9), // "setNlTime"
QT_MOC_LITERAL(54, 726, 8), // "nlTimeEn"
QT_MOC_LITERAL(55, 735, 11), // "setTermTime"
QT_MOC_LITERAL(56, 747, 10), // "termTimeEn"
QT_MOC_LITERAL(57, 758, 9), // "setTermLC"
QT_MOC_LITERAL(58, 768, 8), // "termLCEn"
QT_MOC_LITERAL(59, 777, 13), // "setTermPaused"
QT_MOC_LITERAL(60, 791, 12), // "termPausedEn"
QT_MOC_LITERAL(61, 804, 18), // "getTermLastMsgSlot"
QT_MOC_LITERAL(62, 823, 6), // "incCnt"
QT_MOC_LITERAL(63, 830, 8), // "sendRCRS"
QT_MOC_LITERAL(64, 839, 7), // "nameReg"
QT_MOC_LITERAL(65, 847, 10), // "regAddress"
QT_MOC_LITERAL(66, 858, 6), // "nodeId"
QT_MOC_LITERAL(67, 865, 6), // "uartId"
QT_MOC_LITERAL(68, 872, 3), // "len"
QT_MOC_LITERAL(69, 876, 6), // "offset"
QT_MOC_LITERAL(70, 883, 8), // "sendSCRS"
QT_MOC_LITERAL(71, 892, 9), // "valueType"
QT_MOC_LITERAL(72, 902, 9), // "sentValue"
QT_MOC_LITERAL(73, 912, 8), // "mulValue"
QT_MOC_LITERAL(74, 921, 10), // "setTimeOut"
QT_MOC_LITERAL(75, 932, 10), // "timeoutStr"
QT_MOC_LITERAL(76, 943, 13), // "timeOutModBus"
QT_MOC_LITERAL(77, 957, 15), // "logicChannelNum"
QT_MOC_LITERAL(78, 973, 11), // "timeOutSCPI"
QT_MOC_LITERAL(79, 985, 14), // "setNumOfSerial"
QT_MOC_LITERAL(80, 1000, 14), // "getNumOfSerial"
QT_MOC_LITERAL(81, 1015, 15), // "getInfoOfSerial"
QT_MOC_LITERAL(82, 1031, 12), // "saveSerialLc"
QT_MOC_LITERAL(83, 1044, 12), // "loadSerialLc"
QT_MOC_LITERAL(84, 1057, 14) // "closeAllSerial"

    },
    "SerialThread\0printPortNameSignal\0\0"
    "outString\0printPortAvaible\0logicChannel\0"
    "avaiblePort\0addSerialLCSignal\0"
    "cleanRxTerminalSignal\0printDataSignal\0"
    "inString\0printDataByte\0inData\0src\0"
    "getProtocolSignal\0protocol\0recievedAdamMsg\0"
    "DATA_UART_ADAM_PACKET*\0rcv_data\0"
    "recievedModBusMsg\0MODBUS_RX_STRUCT*\0"
    "recievedSCPIMsg\0SCPIdata\0regName\0"
    "getNumOfSerialSignal\0numOfSerial\0"
    "getInfoOfSerialSignal\0fileName\0baudRate\0"
    "dataLenght\0parity\0stopBit\0bufferSize\0"
    "modbusTimeout\0editItemProtocolChanged\0"
    "getStringDataInSignal\0dataIn\0"
    "getTermLastMsgSignal\0lastData\0addSlots\0"
    "portName\0startSlots\0stopSlots\0restartSlot\0"
    "readSerialSlots\0writeSerialSlots\0"
    "sendData\0getPortNameSlot\0getProtocol\0"
    "setProtocol\0getSerialStatus\0"
    "getStringDataInSlot\0clrStringDataInSlot\0"
    "setNlTime\0nlTimeEn\0setTermTime\0"
    "termTimeEn\0setTermLC\0termLCEn\0"
    "setTermPaused\0termPausedEn\0"
    "getTermLastMsgSlot\0incCnt\0sendRCRS\0"
    "nameReg\0regAddress\0nodeId\0uartId\0len\0"
    "offset\0sendSCRS\0valueType\0sentValue\0"
    "mulValue\0setTimeOut\0timeoutStr\0"
    "timeOutModBus\0logicChannelNum\0timeOutSCPI\0"
    "setNumOfSerial\0getNumOfSerial\0"
    "getInfoOfSerial\0saveSerialLc\0loadSerialLc\0"
    "closeAllSerial"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SerialThread[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  229,    2, 0x06 /* Public */,
       4,    2,  232,    2, 0x06 /* Public */,
       7,    1,  237,    2, 0x06 /* Public */,
       8,    0,  240,    2, 0x06 /* Public */,
       9,    1,  241,    2, 0x06 /* Public */,
      11,    2,  244,    2, 0x06 /* Public */,
      14,    1,  249,    2, 0x06 /* Public */,
      16,    1,  252,    2, 0x06 /* Public */,
      19,    2,  255,    2, 0x06 /* Public */,
      21,    3,  260,    2, 0x06 /* Public */,
      24,    1,  267,    2, 0x06 /* Public */,
      26,    9,  270,    2, 0x06 /* Public */,
      34,    2,  289,    2, 0x06 /* Public */,
      35,    1,  294,    2, 0x06 /* Public */,
      37,    1,  297,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      39,    7,  300,    2, 0x0a /* Public */,
      41,    7,  315,    2, 0x0a /* Public */,
      42,    1,  330,    2, 0x0a /* Public */,
      43,    1,  333,    2, 0x0a /* Public */,
      44,    0,  336,    2, 0x0a /* Public */,
      45,    2,  337,    2, 0x0a /* Public */,
      47,    0,  342,    2, 0x0a /* Public */,
      48,    1,  343,    2, 0x0a /* Public */,
      49,    2,  346,    2, 0x0a /* Public */,
      50,    1,  351,    2, 0x0a /* Public */,
      51,    0,  354,    2, 0x0a /* Public */,
      52,    0,  355,    2, 0x0a /* Public */,
      53,    1,  356,    2, 0x0a /* Public */,
      55,    1,  359,    2, 0x0a /* Public */,
      57,    1,  362,    2, 0x0a /* Public */,
      59,    1,  365,    2, 0x0a /* Public */,
      61,    1,  368,    2, 0x0a /* Public */,
      63,    7,  371,    2, 0x0a /* Public */,
      70,   10,  386,    2, 0x0a /* Public */,
      74,    2,  407,    2, 0x0a /* Public */,
      76,    1,  412,    2, 0x0a /* Public */,
      78,    1,  415,    2, 0x0a /* Public */,
      79,    1,  418,    2, 0x0a /* Public */,
      80,    0,  421,    2, 0x0a /* Public */,
      81,    1,  422,    2, 0x0a /* Public */,
      82,    1,  425,    2, 0x0a /* Public */,
      83,    1,  428,    2, 0x0a /* Public */,
      84,    0,  431,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QStringList,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    5,    6,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QByteArray, QMetaType::Int,   12,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, 0x80000000 | 20, QMetaType::QString,   18,    5,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   22,    5,   23,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   25,   27,   28,   29,   30,   31,   32,   15,   33,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    5,   15,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void, QMetaType::QString,   38,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    5,   40,   28,   29,   30,   31,   32,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    5,   27,   28,   29,   30,   31,   32,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    5,   46,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    5,   15,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   54,
    QMetaType::Void, QMetaType::Bool,   56,
    QMetaType::Void, QMetaType::Bool,   58,
    QMetaType::Void, QMetaType::Bool,   60,
    QMetaType::Void, QMetaType::Bool,   62,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,   64,   65,   66,   67,   68,   69,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    5,   71,   64,   72,   65,   66,   67,   68,   69,   73,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    5,   75,
    QMetaType::Void, QMetaType::Int,   77,
    QMetaType::Void, QMetaType::Int,   77,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void,

       0        // eod
};

void SerialThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SerialThread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->printPortNameSignal((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 1: _t->printPortAvaible((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 2: _t->addSerialLCSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->cleanRxTerminalSignal(); break;
        case 4: _t->printDataSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->printDataByte((*reinterpret_cast< QByteArray(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 6: _t->getProtocolSignal((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 7: _t->recievedAdamMsg((*reinterpret_cast< DATA_UART_ADAM_PACKET*(*)>(_a[1]))); break;
        case 8: _t->recievedModBusMsg((*reinterpret_cast< MODBUS_RX_STRUCT*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->recievedSCPIMsg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 10: _t->getNumOfSerialSignal((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 11: _t->getInfoOfSerialSignal((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< qint32(*)>(_a[6])),(*reinterpret_cast< qint32(*)>(_a[7])),(*reinterpret_cast< qint32(*)>(_a[8])),(*reinterpret_cast< qint32(*)>(_a[9]))); break;
        case 12: _t->editItemProtocolChanged((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 13: _t->getStringDataInSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->getTermLastMsgSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->addSlots((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< qint32(*)>(_a[6])),(*reinterpret_cast< qint32(*)>(_a[7]))); break;
        case 16: _t->startSlots((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint32(*)>(_a[3])),(*reinterpret_cast< qint32(*)>(_a[4])),(*reinterpret_cast< qint32(*)>(_a[5])),(*reinterpret_cast< qint32(*)>(_a[6])),(*reinterpret_cast< qint32(*)>(_a[7]))); break;
        case 17: _t->stopSlots((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 18: _t->restartSlot((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 19: _t->readSerialSlots(); break;
        case 20: _t->writeSerialSlots((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 21: _t->getPortNameSlot(); break;
        case 22: _t->getProtocol((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 23: _t->setProtocol((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 24: _t->getSerialStatus((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 25: _t->getStringDataInSlot(); break;
        case 26: _t->clrStringDataInSlot(); break;
        case 27: _t->setNlTime((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->setTermTime((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->setTermLC((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->setTermPaused((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->getTermLastMsgSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->sendRCRS((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7]))); break;
        case 33: _t->sendSCRS((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< QString(*)>(_a[6])),(*reinterpret_cast< QString(*)>(_a[7])),(*reinterpret_cast< QString(*)>(_a[8])),(*reinterpret_cast< QString(*)>(_a[9])),(*reinterpret_cast< QString(*)>(_a[10]))); break;
        case 34: _t->setTimeOut((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 35: _t->timeOutModBus((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 36: _t->timeOutSCPI((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 37: _t->setNumOfSerial((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 38: _t->getNumOfSerial(); break;
        case 39: _t->getInfoOfSerial((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 40: _t->saveSerialLc((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 41: _t->loadSerialLc((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 42: _t->closeAllSerial(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SerialThread::*)(QStringList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::printPortNameSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(qint32 , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::printPortAvaible)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::addSerialLCSignal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::cleanRxTerminalSignal)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::printDataSignal)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QByteArray , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::printDataByte)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::getProtocolSignal)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(DATA_UART_ADAM_PACKET * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::recievedAdamMsg)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(MODBUS_RX_STRUCT * , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::recievedModBusMsg)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::recievedSCPIMsg)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::getNumOfSerialSignal)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(qint32 , QString , qint32 , qint32 , qint32 , qint32 , qint32 , qint32 , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::getInfoOfSerialSignal)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::editItemProtocolChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::getStringDataInSignal)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (SerialThread::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SerialThread::getTermLastMsgSignal)) {
                *result = 14;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SerialThread::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_SerialThread.data,
    qt_meta_data_SerialThread,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SerialThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SerialThread.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int SerialThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 43;
    }
    return _id;
}

// SIGNAL 0
void SerialThread::printPortNameSignal(QStringList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SerialThread::printPortAvaible(qint32 _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SerialThread::addSerialLCSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SerialThread::cleanRxTerminalSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void SerialThread::printDataSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SerialThread::printDataByte(QByteArray _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SerialThread::getProtocolSignal(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SerialThread::recievedAdamMsg(DATA_UART_ADAM_PACKET * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SerialThread::recievedModBusMsg(MODBUS_RX_STRUCT * _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SerialThread::recievedSCPIMsg(QString _t1, QString _t2, QString _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SerialThread::getNumOfSerialSignal(qint32 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void SerialThread::getInfoOfSerialSignal(qint32 _t1, QString _t2, qint32 _t3, qint32 _t4, qint32 _t5, qint32 _t6, qint32 _t7, qint32 _t8, qint32 _t9)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void SerialThread::editItemProtocolChanged(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void SerialThread::getStringDataInSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void SerialThread::getTermLastMsgSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
