/****************************************************************************
** Meta object code from reading C++ file 'graph.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/graph/graph.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'graph.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Graph_t {
    QByteArrayData data[17];
    char stringdata0[168];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Graph_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Graph_t qt_meta_stringdata_Graph = {
    {
QT_MOC_LITERAL(0, 0, 5), // "Graph"
QT_MOC_LITERAL(1, 6, 11), // "QML.Element"
QT_MOC_LITERAL(2, 18, 4), // "auto"
QT_MOC_LITERAL(3, 23, 10), // "setMaxLine"
QT_MOC_LITERAL(4, 34, 0), // ""
QT_MOC_LITERAL(5, 35, 8), // "maxlLine"
QT_MOC_LITERAL(6, 44, 12), // "appendSample"
QT_MOC_LITERAL(7, 57, 12), // "QList<qreal>"
QT_MOC_LITERAL(8, 70, 5), // "value"
QT_MOC_LITERAL(9, 76, 17), // "removeFirstSample"
QT_MOC_LITERAL(10, 94, 13), // "removeSamples"
QT_MOC_LITERAL(11, 108, 12), // "cntOfRemoved"
QT_MOC_LITERAL(12, 121, 11), // "updateGraph"
QT_MOC_LITERAL(13, 133, 8), // "gridSize"
QT_MOC_LITERAL(14, 142, 7), // "disGrid"
QT_MOC_LITERAL(15, 150, 6), // "disBck"
QT_MOC_LITERAL(16, 157, 10) // "updateArea"

    },
    "Graph\0QML.Element\0auto\0setMaxLine\0\0"
    "maxlLine\0appendSample\0QList<qreal>\0"
    "value\0removeFirstSample\0removeSamples\0"
    "cntOfRemoved\0updateGraph\0gridSize\0"
    "disGrid\0disBck\0updateArea"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Graph[] = {

 // content:
       8,       // revision
       0,       // classname
       1,   14, // classinfo
       6,   16, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
       1,    2,

 // slots: name, argc, parameters, tag, flags
       3,    1,   46,    4, 0x0a /* Public */,
       6,    1,   49,    4, 0x0a /* Public */,
       9,    0,   52,    4, 0x0a /* Public */,
      10,    1,   53,    4, 0x0a /* Public */,
      12,    3,   56,    4, 0x0a /* Public */,
      16,    0,   63,    4, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool, QMetaType::Bool,   13,   14,   15,
    QMetaType::Void,

       0        // eod
};

void Graph::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Graph *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->setMaxLine((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 1: _t->appendSample((*reinterpret_cast< QList<qreal>(*)>(_a[1]))); break;
        case 2: _t->removeFirstSample(); break;
        case 3: _t->removeSamples((*reinterpret_cast< qint32(*)>(_a[1]))); break;
        case 4: _t->updateGraph((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 5: _t->updateArea(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<qreal> >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Graph::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickItem::staticMetaObject>(),
    qt_meta_stringdata_Graph.data,
    qt_meta_data_Graph,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Graph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Graph::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Graph.stringdata0))
        return static_cast<void*>(this);
    return QQuickItem::qt_metacast(_clname);
}

int Graph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
