/****************************************************************************
** Meta object code from reading C++ file 'common.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ArmStand-1-1/common.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'common.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_common_t {
    QByteArrayData data[40];
    char stringdata0[562];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_common_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_common_t qt_meta_stringdata_common = {
    {
QT_MOC_LITERAL(0, 0, 6), // "common"
QT_MOC_LITERAL(1, 7, 13), // "saveDataModel"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 10), // "fileSource"
QT_MOC_LITERAL(4, 33, 14), // "saveDataLayout"
QT_MOC_LITERAL(5, 48, 4), // "page"
QT_MOC_LITERAL(6, 53, 10), // "saveDataLC"
QT_MOC_LITERAL(7, 64, 13), // "loadDataModel"
QT_MOC_LITERAL(8, 78, 12), // "logicChannel"
QT_MOC_LITERAL(9, 91, 8), // "protocol"
QT_MOC_LITERAL(10, 100, 11), // "openProject"
QT_MOC_LITERAL(11, 112, 14), // "loadDataLayout"
QT_MOC_LITERAL(12, 127, 6), // "loadLC"
QT_MOC_LITERAL(13, 134, 12), // "loadImageBck"
QT_MOC_LITERAL(14, 147, 4), // "path"
QT_MOC_LITERAL(15, 152, 14), // "closeDataModel"
QT_MOC_LITERAL(16, 167, 9), // "deleteAll"
QT_MOC_LITERAL(17, 177, 11), // "closeLayout"
QT_MOC_LITERAL(18, 189, 14), // "closeAllButton"
QT_MOC_LITERAL(19, 204, 14), // "closeAllSerial"
QT_MOC_LITERAL(20, 219, 14), // "recentLoadProj"
QT_MOC_LITERAL(21, 234, 4), // "name"
QT_MOC_LITERAL(22, 239, 15), // "printInfoSignal"
QT_MOC_LITERAL(23, 255, 4), // "info"
QT_MOC_LITERAL(24, 260, 18), // "printProjectSignal"
QT_MOC_LITERAL(25, 279, 28), // "connectionSettingClickSignal"
QT_MOC_LITERAL(26, 308, 25), // "createProtocolClickSignal"
QT_MOC_LITERAL(27, 334, 23), // "modelSettingClickSignal"
QT_MOC_LITERAL(28, 358, 21), // "newProjectClickSignal"
QT_MOC_LITERAL(29, 380, 11), // "saveProject"
QT_MOC_LITERAL(30, 392, 11), // "loadProject"
QT_MOC_LITERAL(31, 404, 12), // "closeProject"
QT_MOC_LITERAL(32, 417, 20), // "getLastLoadedProject"
QT_MOC_LITERAL(33, 438, 9), // "printInfo"
QT_MOC_LITERAL(34, 448, 12), // "printProject"
QT_MOC_LITERAL(35, 461, 7), // "project"
QT_MOC_LITERAL(36, 469, 26), // "connectionSettingClickSlot"
QT_MOC_LITERAL(37, 496, 23), // "createProtocolClickSlot"
QT_MOC_LITERAL(38, 520, 21), // "modelSettingClickSlot"
QT_MOC_LITERAL(39, 542, 19) // "newProjectClickSlot"

    },
    "common\0saveDataModel\0\0fileSource\0"
    "saveDataLayout\0page\0saveDataLC\0"
    "loadDataModel\0logicChannel\0protocol\0"
    "openProject\0loadDataLayout\0loadLC\0"
    "loadImageBck\0path\0closeDataModel\0"
    "deleteAll\0closeLayout\0closeAllButton\0"
    "closeAllSerial\0recentLoadProj\0name\0"
    "printInfoSignal\0info\0printProjectSignal\0"
    "connectionSettingClickSignal\0"
    "createProtocolClickSignal\0"
    "modelSettingClickSignal\0newProjectClickSignal\0"
    "saveProject\0loadProject\0closeProject\0"
    "getLastLoadedProject\0printInfo\0"
    "printProject\0project\0connectionSettingClickSlot\0"
    "createProtocolClickSlot\0modelSettingClickSlot\0"
    "newProjectClickSlot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_common[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      18,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  154,    2, 0x06 /* Public */,
       4,    2,  157,    2, 0x06 /* Public */,
       6,    1,  162,    2, 0x06 /* Public */,
       7,    4,  165,    2, 0x06 /* Public */,
      11,    2,  174,    2, 0x06 /* Public */,
      12,    1,  179,    2, 0x06 /* Public */,
      13,    2,  182,    2, 0x06 /* Public */,
      15,    1,  187,    2, 0x06 /* Public */,
      17,    0,  190,    2, 0x06 /* Public */,
      18,    0,  191,    2, 0x06 /* Public */,
      19,    0,  192,    2, 0x06 /* Public */,
      20,    2,  193,    2, 0x06 /* Public */,
      22,    1,  198,    2, 0x06 /* Public */,
      24,    1,  201,    2, 0x06 /* Public */,
      25,    0,  204,    2, 0x06 /* Public */,
      26,    0,  205,    2, 0x06 /* Public */,
      27,    0,  206,    2, 0x06 /* Public */,
      28,    0,  207,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      29,    1,  208,    2, 0x0a /* Public */,
      30,    1,  211,    2, 0x0a /* Public */,
      31,    0,  214,    2, 0x0a /* Public */,
      32,    0,  215,    2, 0x0a /* Public */,
      33,    1,  216,    2, 0x0a /* Public */,
      34,    1,  219,    2, 0x0a /* Public */,
      36,    0,  222,    2, 0x0a /* Public */,
      37,    0,  223,    2, 0x0a /* Public */,
      38,    0,  224,    2, 0x0a /* Public */,
      39,    0,  225,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    5,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    3,    8,    9,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    3,    5,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    5,   14,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,   21,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void common::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<common *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->saveDataModel((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->saveDataLayout((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 2: _t->saveDataLC((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->loadDataModel((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 4: _t->loadDataLayout((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2]))); break;
        case 5: _t->loadLC((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->loadImageBck((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->closeDataModel((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->closeLayout(); break;
        case 9: _t->closeAllButton(); break;
        case 10: _t->closeAllSerial(); break;
        case 11: _t->recentLoadProj((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 12: _t->printInfoSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->printProjectSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->connectionSettingClickSignal(); break;
        case 15: _t->createProtocolClickSignal(); break;
        case 16: _t->modelSettingClickSignal(); break;
        case 17: _t->newProjectClickSignal(); break;
        case 18: _t->saveProject((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->loadProject((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->closeProject(); break;
        case 21: _t->getLastLoadedProject(); break;
        case 22: _t->printInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 23: _t->printProject((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->connectionSettingClickSlot(); break;
        case 25: _t->createProtocolClickSlot(); break;
        case 26: _t->modelSettingClickSlot(); break;
        case 27: _t->newProjectClickSlot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (common::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::saveDataModel)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (common::*)(QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::saveDataLayout)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (common::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::saveDataLC)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (common::*)(QString , QString , QString , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::loadDataModel)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (common::*)(QString , qint32 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::loadDataLayout)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (common::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::loadLC)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (common::*)(qint32 , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::loadImageBck)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (common::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::closeDataModel)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::closeLayout)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::closeAllButton)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::closeAllSerial)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (common::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::recentLoadProj)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (common::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::printInfoSignal)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (common::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::printProjectSignal)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::connectionSettingClickSignal)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::createProtocolClickSignal)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::modelSettingClickSignal)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (common::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&common::newProjectClickSignal)) {
                *result = 17;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject common::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_common.data,
    qt_meta_data_common,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *common::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *common::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_common.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int common::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}

// SIGNAL 0
void common::saveDataModel(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void common::saveDataLayout(QString _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void common::saveDataLC(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void common::loadDataModel(QString _t1, QString _t2, QString _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void common::loadDataLayout(QString _t1, qint32 _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void common::loadLC(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void common::loadImageBck(qint32 _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void common::closeDataModel(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void common::closeLayout()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void common::closeAllButton()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void common::closeAllSerial()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void common::recentLoadProj(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void common::printInfoSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void common::printProjectSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void common::connectionSettingClickSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void common::createProtocolClickSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void common::modelSettingClickSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void common::newProjectClickSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
