/****************************************************************************
** Generated QML type registration code
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <QtQml/qqml.h>
#include <QtQml/qqmlmoduleregistration.h>

#include <graph.h>

void qml_register_types_Graph()
{
    qmlRegisterTypesAndRevisions<Graph>("Graph", 1);
    qmlRegisterModule("Graph", 1, 0);
}

static const QQmlModuleRegistration registration("Graph", 1, qml_register_types_Graph);
